const db = require('../DATABASE/mysql');
const { getFullImageUrl } = require('../utils/imageUtils');

// 🛡️ Helper: Convert any format of subcategories into a clean JSON string for MySQL
const formatSubcategoriesForDB = (val) => {
    if (!val) return null;
    if (Array.isArray(val)) {
        const cleanArr = val.map(Number).filter(n => !isNaN(n) && n > 0);
        return cleanArr.length > 0 ? JSON.stringify(cleanArr) : null;
    }
    if (typeof val === 'string') {
        try {
            const parsed = JSON.parse(val);
            if (Array.isArray(parsed)) {
                const cleanArr = parsed.map(Number).filter(n => !isNaN(n) && n > 0);
                return cleanArr.length > 0 ? JSON.stringify(cleanArr) : null;
            }
            if (!isNaN(Number(parsed)) && Number(parsed) > 0) {
                return JSON.stringify([Number(parsed)]);
            }
        } catch (e) {
            const parts = val.split(',').map(s => Number(s.trim())).filter(n => !isNaN(n) && n > 0);
            if (parts.length > 0) return JSON.stringify(parts);
        }
    }
    if (typeof val === 'number' && val > 0) {
        return JSON.stringify([val]);
    }
    return null;
};

// 🛡️ Helper: Parse JSON safely from DB response
const parseSafeJson = (val) => {
    if (!val) return [];
    if (Array.isArray(val)) return val;
    if (typeof val === 'string') {
        try {
            const parsed = JSON.parse(val);
            return Array.isArray(parsed) ? parsed : [parsed];
        } catch (e) {
            return [];
        }
    }
    return [];
};

const productsearch = async(keyword, minprice, maxprice) => {
    console.log(`[PRODUCT_SERVICE] Searching products with keyword: "${keyword}", min: ${minprice}, max: ${maxprice}`);
    try {
        const searchvalue = '%' + keyword + '%';
        let sqlquery = `
            SELECT *, 
            IF(mrp > price, ROUND(((mrp - price) / mrp) * 100), 0) AS calculated_discount 
            FROM products 
            WHERE (name LIKE ? OR description LIKE ?)
        `;
        let queryvalue = [searchvalue, searchvalue];

        if(minprice){
            sqlquery += ' AND price >= ?';
            queryvalue.push(Number(minprice));
        }
        if(maxprice){
            sqlquery += ' AND price <= ?';
            queryvalue.push(Number(maxprice));
        }

        const [result] = await db.execute(sqlquery, queryvalue);
        console.log(`[PRODUCT_SERVICE] Search found ${result.length} products.`);
        
        return result.map(product => ({
            ...product,
            discount_percentage: product.calculated_discount,
            image_url: getFullImageUrl(product.image_url)
        }));
    } catch (err) {
        console.error('[PRODUCT_SERVICE] ❌ Error in productsearch:', err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const productdelete = async(product_id) => {
    console.log(`[PRODUCT_SERVICE] Deleting product with ID: ${product_id}`);
    try {
        const deleteImagesQuery = 'DELETE FROM product_images WHERE product_id = ?';
        await db.execute(deleteImagesQuery, [product_id]);
        console.log(`[PRODUCT_SERVICE] Associated images deleted for product ID: ${product_id}`);

        const deletequery = 'DELETE FROM products WHERE product_id = ?';
        const [result] = await db.execute(deletequery, [product_id]);
        console.log(`[PRODUCT_SERVICE] ✅ Product deleted successfully. Affected rows: ${result.affectedRows}`);

        return result;
    } catch (err) {
        console.error(`[PRODUCT_SERVICE] ❌ Error deleting product ID ${product_id}:`, err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const allproductget = async(minPrice, maxPrice, limit, offset) => {
    console.log(`[PRODUCT_SERVICE] Fetching all products. Limit: ${limit}, Offset: ${offset}, Min: ${minPrice}, Max: ${maxPrice}`);
    try {
        let query = `
            SELECT *, 
            IF(mrp > price, ROUND(((mrp - price) / mrp) * 100), 0) AS calculated_discount 
            FROM products
        `;
        let queryParams = [];
        
        if (minPrice !== null && maxPrice !== null && !isNaN(minPrice) && !isNaN(maxPrice)) {
            query += ` WHERE price >= ? AND price <= ?`;
            queryParams.push(minPrice, maxPrice);
        }
        
        query += ` ORDER BY product_id DESC`;
        query += ` LIMIT ${Number(limit)} OFFSET ${Number(offset)}`;

        const [results] = await db.execute(query, queryParams);
        console.log(`[PRODUCT_SERVICE] ✅ Fetched ${results.length} products successfully.`);
        
        return results.map(product => ({
            ...product,
            product_length: product.product_length || '',
            subcategory_ids: parseSafeJson(product.subcategory_ids),
            discount_percentage: product.calculated_discount,
            image_url: getFullImageUrl(product.image_url)
        }));
    } catch (err) {
        console.error('[PRODUCT_SERVICE] ❌ Error in allproductget:', err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const productrecomendution = async(product_id, category_id, subcategory_id) => {
    console.log(`[PRODUCT_SERVICE] Fetching recommendations for Product ID: ${product_id}, SubCat: ${subcategory_id}, Cat: ${category_id}`);
    const RECOMMENDATION_LIMIT = 6;
    try {
        if (subcategory_id) {
            const priceQuery = `SELECT price FROM products WHERE product_id = ?`;
            const [priceResult] = await db.execute(priceQuery, [product_id]);
            const currentPrice = priceResult[0]?.price || 0;
    
            const query = `
                SELECT product_id, name, price, mrp, image_url, subcategory_id,
                IF(mrp > price, ROUND(((mrp - price) / mrp) * 100), 0) AS calculated_discount
                FROM products 
                WHERE subcategory_id = ? AND product_id != ? AND stock_qty > 0
                ORDER BY RAND(), ABS(price - ?) ASC
                LIMIT ${RECOMMENDATION_LIMIT}
            `;
    
            const [results] = await db.execute(query, [subcategory_id, product_id, currentPrice]);
            console.log(`[PRODUCT_SERVICE] ✅ Subcategory recommendations found: ${results.length}`);
            
            return results.map(product => ({
                ...product,
                discount_percentage: product.calculated_discount,
                image_url: getFullImageUrl(product.image_url)
            }));
        } else {
            const query = `
                SELECT product_id, name, price, mrp, image_url, subcategory_id,
                IF(mrp > price, ROUND(((mrp - price) / mrp) * 100), 0) AS calculated_discount
                FROM products 
                WHERE category_id = ? AND product_id != ? AND stock_qty > 0
                ORDER BY RAND()
                LIMIT ${RECOMMENDATION_LIMIT}
            `;
     
            const [results] = await db.execute(query, [category_id, product_id]);
            console.log(`[PRODUCT_SERVICE] ✅ Category recommendations found: ${results.length}`);
            
            return results.map(product => ({
                ...product,
                discount_percentage: product.calculated_discount,
                image_url: getFullImageUrl(product.image_url)
            }));
        }
    } catch (err) {
        console.error('[PRODUCT_SERVICE] ❌ Error in productrecomendution:', err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const getproduct = async() => {
    console.log(`[PRODUCT_SERVICE] Fetching all raw products list...`);
    try {
        const query = `
            SELECT *, 
            IF(mrp > price, ROUND(((mrp - price) / mrp) * 100), 0) AS calculated_discount 
            FROM products
        `;
        const [result] = await db.execute(query);
        console.log(`[PRODUCT_SERVICE] ✅ Total raw products fetched: ${result.length}`);
        return result.map(product => ({
            ...product,
            product_length: product.product_length || '',
            subcategory_ids: parseSafeJson(product.subcategory_ids),
            discount_percentage: product.calculated_discount
        }));
    } catch (err) {
        console.error('[PRODUCT_SERVICE] ❌ Error in getproduct:', err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const getbyidproduct = async (productId) => {
    console.log(`[PRODUCT_SERVICE] 🔍 Fetching product details for ID: ${productId}`);
    try {
        const productQuery = `
            SELECT 
                p.*,
                COALESCE(
                    (
                        SELECT JSON_ARRAYAGG(JSON_OBJECT('id', s.subcategory_id, 'name', s.subcategory_name))
                        FROM subcategories s
                        WHERE (
                            p.subcategory_ids IS NOT NULL 
                            AND JSON_CONTAINS(p.subcategory_ids, CAST(s.subcategory_id AS JSON))
                        )
                        OR s.subcategory_id = p.subcategory_id
                    ),
                    '[]'
                ) AS subcategory_details,
                IF(p.mrp > p.price, ROUND(((p.mrp - p.price) / p.mrp) * 100), 0) AS calculated_discount 
            FROM products p 
            WHERE p.product_id = ?
            LIMIT 1
        `;
        const [productResults] = await db.execute(productQuery, [productId]);

        if (productResults.length === 0) {
            console.warn(`[PRODUCT_SERVICE] ⚠️ Product not found with ID: ${productId}`);
            return null; 
        }
        const product = productResults[0];
        
        console.log(`[PRODUCT_SERVICE] 📌 Found Product Name: "${product.name}", Group ID in DB: "${product.group_id}"`);

        product.discount_percentage = product.calculated_discount;
        product.color_name = product.base_color; 
        product.product_length = product.product_length || '';
        product.subcategory_ids = parseSafeJson(product.subcategory_ids);
        product.subcategory_details = parseSafeJson(product.subcategory_details);

        // 1. Fetch Multiple Images
        const imagesQuery = `SELECT image_url FROM product_images WHERE product_id = ?`;
        const [imageResults] = await db.execute(imagesQuery, [productId]);
        
        const allImages = [];
        if (product.image_url) allImages.push(getFullImageUrl(product.image_url));
        if (imageResults && imageResults.length > 0) {
            imageResults.forEach(img => allImages.push(getFullImageUrl(img.image_url)));
        }
        
        product.images = [...new Set(allImages)];
        product.gallery_images = [...new Set(allImages)];
        product.image_url = getFullImageUrl(product.image_url);

        // 2. Variants fetch logic
        let variantResults = [];
        if (product.group_id !== null && product.group_id !== undefined && String(product.group_id).trim() !== '') {
            const rawGroupId = product.group_id; 
            console.log(`[PRODUCT_SERVICE] 🔍 Executing variants query for group_id: ${rawGroupId} excluding product ID: ${productId}`);
            
            const variantsQuery = `
                SELECT product_id, base_color AS color_name, image_url, is_active, stock_qty
                FROM products 
                WHERE group_id = ? AND product_id != ?
            `;
            [variantResults] = await db.execute(variantsQuery, [rawGroupId, productId]);
            console.log(`[PRODUCT_SERVICE] ✅ Variants query returned ${variantResults.length} row(s).`);
        }

        product.variants = variantResults
            .filter(v => v.is_active === 1)
            .map(v => ({
                product_id: v.product_id,
                color_name: v.color_name || 'Variant',
                image_url: getFullImageUrl(v.image_url),
                stock_qty: v.stock_qty
            }));

        return product;
    } catch (err) {
        console.error(`[PRODUCT_SERVICE] ❌ Error in getbyidproduct for ID ${productId}:`, err.message);
        throw err;
    }
};

const addProductToDB = async (productData) => {
    console.log(`[PRODUCT_SERVICE] Attempting to add new product: "${productData?.name}"`);
    try {
        const {
            name, price, description, base_color, category_id, stock_qty, is_active = 1, mainImage, video_url,
            primary_color, other_color, border_type, pattern, craft, weave, zari_type, 
            blouse, border_motifs, origin, fabric, khats, weight, blouse_length, producer, maker,
            extraImagesUrls, mrp, dealer_base_price, packaging_cost, is_returnable, dealer_id, producer_address, packer_address, group_id,
            product_length, subcategory_ids
        } = productData;

        const parsedPrice = Number(price) || 0;
        const parsedMrp = Number(mrp) || 0;
        const computedDiscount = (parsedMrp > parsedPrice) ? Math.round(((parsedMrp - parsedPrice) / parsedMrp) * 100) : 0;
        const safeIsReturnable = (is_returnable === true || is_returnable === '1' || is_returnable === 1) ? 1 : 0;

        const categoryQuery = 'SELECT category_id FROM categories WHERE category_id = ?';
        const [categoryResult] = await db.execute(categoryQuery, [category_id]);
        
        if (categoryResult.length === 0) {
            console.warn(`[PRODUCT_SERVICE] ⚠️ Category not found with ID: ${category_id}`);
            throw new Error('CATEGORY_NOT_FOUND');
        }

        const duplicateQuery = 'SELECT product_id FROM products WHERE name = ? AND category_id = ?';
        const [productResult] = await db.execute(duplicateQuery, [name, category_id]);
        
        if (productResult.length > 0) {
            console.warn(`[PRODUCT_SERVICE] ⚠️ Duplicate product detected: "${name}" in category ID ${category_id}`);
            throw new Error('DUPLICATE_PRODUCT');
        }

        // Clean & Format subcategories for JSON column
        const subcatJson = formatSubcategoriesForDB(subcategory_ids);

        const insertProductQuery = `
          INSERT INTO products (
            name, price, description, base_color, category_id, stock_qty, is_active, image_url,
            primary_color, other_color, border_type, pattern, craft, weave, zari_type, 
            blouse, border_motifs, origin, fabric, khats, weight, blouse_length, producer, maker,
            mrp, discount_percentage, dealer_base_price, packaging_cost, is_returnable, dealer_id, producer_address, packer_address, group_id, video_url,
            product_length, subcategory_ids
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `;

        const values = [
          name, 
          parsedPrice, 
          description || null, 
          base_color || null, 
          Number(category_id) || 0, 
          Number(stock_qty) || 10, 
          Number(is_active) || 1, 
          mainImage || null,
          primary_color || null, 
          other_color || null, 
          border_type || null, 
          pattern || null, 
          craft || null, 
          weave || null, 
          zari_type || null, 
          blouse || null, 
          border_motifs || null, 
          origin || null, 
          fabric || null, 
          khats || null, 
          weight || null, 
          blouse_length || null, 
          producer || null, 
          maker || null,
          parsedMrp ? parsedMrp : null,
          computedDiscount,
          dealer_base_price ? Number(dealer_base_price) : null,
          packaging_cost ? Number(packaging_cost) : null,
          safeIsReturnable, 
          dealer_id || null,
          producer_address || null,
          packer_address || null,
          group_id || null,
          video_url || null,
          product_length || null,
          subcatJson
        ];

        const [result] = await db.execute(insertProductQuery, values);
        const newProductId = result.insertId;
        console.log(`[PRODUCT_SERVICE] ✅ Main product inserted successfully with ID: ${newProductId}`);

        if (typeof myCache !== 'undefined') {
            myCache.del('all_products'); 
        }
        
        if (extraImagesUrls && extraImagesUrls.length > 0) {
            console.log(`[PRODUCT_SERVICE] Inserting ${extraImagesUrls.length} extra images for new product ID: ${newProductId}`);
            const insertImagesQuery = `INSERT INTO product_images (product_id, image_url, is_primary) VALUES ?`;
            const imageValues = extraImagesUrls.map(url => [newProductId, url, false]);
            await db.query(insertImagesQuery, [imageValues]); 
            console.log(`[PRODUCT_SERVICE] ✅ Extra images inserted successfully.`);
        }

        return newProductId;
    } catch (err) {
        console.error(`[PRODUCT_SERVICE] ❌ Error in addProductToDB:`, err.message);
        throw err;
    }
};

const updateProductInDB = async (product_id, updateData) => {
    console.log(`[PRODUCT_SERVICE] Attempting to update product ID: ${product_id}`);
    try {
        const checkQuery = 'SELECT product_id FROM products WHERE product_id=?';
        const [checkResult] = await db.execute(checkQuery, [product_id]);
        
        if (checkResult.length === 0) {
            console.warn(`[PRODUCT_SERVICE] ⚠️ Update failed. Product not found with ID: ${product_id}`);
            throw new Error('PRODUCT_NOT_FOUND');
        }

        const { 
            category_id, name, description, price, stock_qty, is_active,
            base_color, primary_color, other_color, border_type, pattern, 
            craft, weave, zari_type, blouse, border_motifs, origin, 
            fabric, khats, weight, blouse_length, producer, maker,
            extraImagesUrls, mainImage, mrp, dealer_base_price, packaging_cost, is_returnable, dealer_id, producer_address, packer_address, group_id, video_url,
            product_length, subcategory_ids
        } = updateData;

        const parsedPrice = Number(price) || 0;
        const parsedMrp = Number(mrp) || 0;
        const computedDiscount = (parsedMrp > parsedPrice) ? Math.round(((parsedMrp - parsedPrice) / parsedMrp) * 100) : 0;
        const safeIsReturnable = (is_returnable === true || is_returnable === '1' || is_returnable === 1) ? 1 : 0;

        const subcatJson = formatSubcategoriesForDB(subcategory_ids);

        let updateQuery = `
          UPDATE products SET 
            category_id=?, name=?, description=?, price=?, stock_qty=?, is_active=?,
            base_color=?, primary_color=?, other_color=?, border_type=?, pattern=?, 
            craft=?, weave=?, zari_type=?, blouse=?, border_motifs=?, origin=?, 
            fabric=?, khats=?, weight=?, blouse_length=?, producer=?, maker=?,
            mrp=?, discount_percentage=?, dealer_base_price=?, packaging_cost=?, is_returnable=?, dealer_id=?, producer_address=?, packer_address=?, group_id=?,
            product_length=?, subcategory_ids=?
        `;
        
        const values = [
            Number(category_id), name, description || null, parsedPrice, Number(stock_qty), Number(is_active),
            base_color || null, primary_color || null, other_color || null, border_type || null, pattern || null,
            craft || null, weave || null, zari_type || null, blouse || null, border_motifs || null, origin || null,
            fabric || null, khats || null, weight || null, blouse_length || null, producer || null, maker || null,
            parsedMrp ? parsedMrp : null,
            computedDiscount,
            dealer_base_price ? Number(dealer_base_price) : null,
            packaging_cost ? Number(packaging_cost) : null,
            safeIsReturnable,
            dealer_id || null,
            producer_address || null,
            packer_address || null,
            group_id || null,
            product_length || null,
            subcatJson
        ];

        if (mainImage) {
            console.log(`[PRODUCT_SERVICE] Updating main image for product ID: ${product_id}`);
            updateQuery += `, image_url=?`;
            values.push(mainImage);
        }

        if (video_url !== undefined && video_url !== null) { 
            console.log(`[PRODUCT_SERVICE] Updating video for product ID: ${product_id}`);
            updateQuery += `, video_url=?`;
            values.push(video_url);
        }

        updateQuery += ` WHERE product_id=?`;
        values.push(Number(product_id));

        await db.execute(updateQuery, values);
        console.log(`[PRODUCT_SERVICE] ✅ Main product data updated successfully for ID: ${product_id}`);
        
        if (typeof myCache !== 'undefined') {
            myCache.del(`product_${product_id}`);
            console.log(`[PRODUCT_CONTROLLER] ⚡ Cache cleared for product ID: ${product_id}`);
        }

        if (extraImagesUrls && extraImagesUrls.length > 0) {
            console.log(`[PRODUCT_SERVICE] Adding ${extraImagesUrls.length} new extra images during update for product ID: ${product_id}`);
            const insertImagesQuery = `INSERT INTO product_images (product_id, image_url, is_primary) VALUES ?`;
            const imageValues = extraImagesUrls.map(url => [Number(product_id), url, false]);
            await db.query(insertImagesQuery, [imageValues]); 
            console.log(`[PRODUCT_SERVICE] ✅ Extra images added successfully during update.`);
        }
        
        return true; 
    } catch (err) {
        console.error(`[PRODUCT_SERVICE] ❌ Error in updateProductInDB for ID ${product_id}:`, err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const addimageindb = async(product_id, uploadedImages) => {
    console.log(`[PRODUCT_SERVICE] Adding ${uploadedImages.length} images via addimageindb for product ID: ${product_id}`);
    try {
        const insertImagesQuery = 'INSERT INTO product_images (product_id, image_url, is_primary) VALUES ?';
        const imageValues = uploadedImages.map(uploaded => [product_id, uploaded.url, false]);
        const [result] = await db.query(insertImagesQuery, [imageValues]); 
        console.log(`[PRODUCT_SERVICE] ✅ Images inserted via addimageindb successfully.`);
        return result;
    } catch (err) {
        console.error(`[PRODUCT_SERVICE] ❌ Error in addimageindb:`, err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const deleteimageindb = async(image_id) => {
    console.log(`[PRODUCT_SERVICE] Deleting image record with image_id: ${image_id}`);
    try {
        const deleteQuery = 'DELETE FROM product_images WHERE image_id = ?';
        const [result] = await db.execute(deleteQuery, [image_id]);
        console.log(`[PRODUCT_SERVICE] ✅ Image deleted successfully. Affected rows: ${result.affectedRows}`);
        return result;
    } catch (err) {
        console.error(`[PRODUCT_SERVICE] ❌ Error in deleteimageindb for image_id ${image_id}:`, err.message);
        console.error('[PRODUCT_SERVICE] Stack:', err.stack);
        throw err;
    }
};

const deleteAllInventoryInDB = async () => {
    console.log(`[INVENTORY_SERVICE] ⚠️ Request to delete ALL inventory items.`);
    const connection = await db.getConnection();
    try {
        await connection.query('SET FOREIGN_KEY_CHECKS = 0');
        const [result] = await connection.query('DELETE FROM products');
        await connection.query('SET FOREIGN_KEY_CHECKS = 1');
        connection.release();
        console.log(`[INVENTORY_SERVICE] ✅ Successfully deleted ${result.affectedRows} items.`);
        return result.affectedRows;
    } catch (err) {
        await connection.query('SET FOREIGN_KEY_CHECKS = 1');
        connection.release();
        console.error('[INVENTORY_SERVICE] ❌ Error in deleteAllInventoryInDB:', err.message);
        throw err;
    }
};

// 📊 Calculation: Dealer Inventory, Product Sales, aur Admin Gross Profit
const getDealerAndAdminFinancials = async (dealer_id = null) => {
    try {
        let inventoryQuery = `
            SELECT 
                COUNT(product_id) AS total_products,
                COALESCE(SUM(stock_qty), 0) AS total_stock_units,
                COALESCE(SUM(stock_qty * dealer_base_price), 0) AS total_dealer_inventory_cost,
                COALESCE(SUM(stock_qty * price), 0) AS total_retail_inventory_value
            FROM products
            WHERE 1=1
        `;
        const inventoryParams = [];
        if (dealer_id) {
            inventoryQuery += ` AND dealer_id = ?`;
            inventoryParams.push(dealer_id);
        }
        const [inventoryResult] = await db.execute(inventoryQuery, inventoryParams);

        // 🌟 FIX: Updated table names ('orderitems' instead of 'order_items') & column ('status' instead of 'order_status')
        let salesQuery = `
            SELECT 
                COALESCE(SUM(oi.quantity), 0) AS total_units_sold,
                COALESCE(SUM(oi.unit_price * oi.quantity), 0) AS total_sales_amount,
                COALESCE(SUM(p.dealer_base_price * oi.quantity), 0) AS total_dealer_payout,
                COALESCE(SUM(p.packaging_cost * oi.quantity), 0) AS total_packaging_expense,
                COALESCE(
                    SUM((oi.unit_price - (COALESCE(p.dealer_base_price, 0) + COALESCE(p.packaging_cost, 0))) * oi.quantity), 
                    0
                ) AS admin_profit
            FROM orderitems oi
            INNER JOIN products p ON oi.product_id = p.product_id
            INNER JOIN orders o ON oi.order_id = o.order_id
            WHERE o.status NOT IN ('cancelled', 'refunded')
        `;
        const salesParams = [];
        if (dealer_id) {
            salesQuery += ` AND p.dealer_id = ?`;
            salesParams.push(dealer_id);
        }
        const [salesResult] = await db.execute(salesQuery, salesParams);

        return {
            inventory: inventoryResult[0],
            financials: salesResult[0]
        };
    } catch (err) {
        console.error('[FINANCIAL_SERVICE] ❌ Error calculating dealer/admin financials:', err.message);
        throw err;
    }
};

module.exports = {
    productsearch,
    productdelete,
    allproductget,
    productrecomendution,
    getproduct,
    getbyidproduct,
    addProductToDB,
    updateProductInDB,
    addimageindb,
    deleteimageindb,
    deleteAllInventoryInDB,
    getDealerAndAdminFinancials
};